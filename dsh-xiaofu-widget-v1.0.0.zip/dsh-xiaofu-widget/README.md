# 小弗余额挂件

独立 DSH 插件，与主题、启动动画、F11 插件互不依赖。

- 立绘：`assets/xiaofu.webp`
- 白色椭圆对话框
- 暗红色文字
- 显示 DeepSeek 余额与今日已用
- 60 秒自动刷新
- 可拖动，位置保存在 localStorage
- 点击立绘收起/展开气泡

API Key 从 DSH credentials 的 `DEEPSEEK_API_KEY` 读取，不会写进前端。
